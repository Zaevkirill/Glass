package com.example.glasslock

import android.app.WallpaperManager
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val palette = listOf(
    0xFFFFFFFF, 0xFFFFE9B8, 0xFFFFD60A, 0xFFFF9F0A, 0xFFFF453A,
    0xFFFF6FAE, 0xFFBF5AF2, 0xFF64D2FF, 0xFF30D158, 0xFF000000
).map { it.toInt() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    style: ClockStyle,
    onStyleChange: (ClockStyle) -> Unit,
    ticker: TimeTicker,
    status: PermissionStatus,
    lockEnabled: Boolean,
    onApply: () -> Unit,
    onDisable: () -> Unit,
    onPreview: () -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onNotifications: () -> Unit,
    onWallpaper: () -> Unit
) {
    val ctx = LocalContext.current
    val wallpaper by produceState<ImageBitmap?>(null, status.wallpaper) {
        value = withContext(Dispatchers.IO) { loadWallpaper(ctx) }
    }
    val now = ticker.now

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF101114))
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Glass Lock", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(
            "Экран блокировки в стиле iOS. Обои — ваши системные.",
            color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp
        )

        // ---- Предпросмотр ----
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .fillMaxWidth(0.62f)
                    .aspectRatio(9f / 19f)
                    .clip(RoundedCornerShape(30.dp))
                    .border(2.dp, Color(0x33FFFFFF), RoundedCornerShape(30.dp))
            ) {
                val wp = wallpaper
                if (wp != null) {
                    Image(
                        bitmap = wp, contentDescription = null,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(listOf(Color(0xFF4B6CB7), Color(0xFF182848)))
                            )
                    )
                }
                IosClock(
                    style = style,
                    hours = TimeFormat.hours(ctx, now),
                    minutes = TimeFormat.minutes(now),
                    date = TimeFormat.date(now),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    sizeFactor = 0.5f
                )
            }
        }

        // ---- Размеры цифр ----
        Section("Цифры") {
            SliderRow("Высота", style.height, 0.6f..2.0f) { onStyleChange(style.copy(height = it)) }
            SliderRow("Ширина", style.width, 0.6f..1.5f) { onStyleChange(style.copy(width = it)) }
            SliderRow("Толщина", style.weight, 0f..1f) { onStyleChange(style.copy(weight = it)) }
            SwitchRow("Часы над минутами (как в iOS)", style.stacked) {
                onStyleChange(style.copy(stacked = it))
            }
            SwitchRow("Показывать дату", style.showDate) {
                onStyleChange(style.copy(showDate = it))
            }
        }

        // ---- Шрифт ----
        Section("Шрифт") {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ClockFonts.all.forEachIndexed { i, f ->
                    FilterChip(
                        selected = style.fontIndex == i,
                        onClick = { onStyleChange(style.copy(fontIndex = i)) },
                        label = { Text(f.title) }
                    )
                }
            }
        }

        // ---- Цвет ----
        Section("Цвет") {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                palette.forEach { c ->
                    val selected = style.colorArgb == c
                    Box(
                        Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(c))
                            .border(
                                if (selected) 3.dp else 1.dp,
                                if (selected) Color(0xFF64D2FF) else Color(0x55FFFFFF),
                                CircleShape
                            )
                            .clickable { onStyleChange(style.copy(colorArgb = c)) }
                    )
                }
            }
            SliderRow("Прозрачность", style.alpha, 0.2f..1f) { onStyleChange(style.copy(alpha = it)) }
        }

        // ---- Разрешения ----
        Section("Разрешения") {
            PermRow("Поверх других окон", status.overlay, onOverlay)
            PermRow("Уведомления (для службы)", status.notifications, onNotifications)
            PermRow("Без оптимизации батареи", status.battery, onBattery)
            PermRow("Доступ к обоям (для предпросмотра)", status.wallpaper, onWallpaper)
        }

        Button(
            onClick = onApply,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                if (lockEnabled) "Применить заново" else "Применить по умолчанию",
                fontSize = 16.sp, fontWeight = FontWeight.SemiBold
            )
        }
        OutlinedButton(
            onClick = onPreview,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Предпросмотр экрана блокировки") }
        if (lockEnabled) {
            OutlinedButton(
                onClick = onDisable,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Выключить экран блокировки") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Surface(color = Color(0xFF1C1D22), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Row {
            Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Text("%.2f".format(value), color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
        Spacer(Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(label: String, granted: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (granted) "✓ " else "✗ ") + label,
            color = if (granted) Color(0xFF30D158) else Color(0xFFFF9F0A),
            fontSize = 14.sp
        )
        Spacer(Modifier.weight(1f))
        if (!granted) TextButton(onClick = onClick) { Text("Выдать") }
    }
}

/** Системные обои для предпросмотра. Без разрешения вернёт null (будет градиент). */
private fun loadWallpaper(ctx: Context): ImageBitmap? = try {
    val d = WallpaperManager.getInstance(ctx).drawable
    if (d == null || d.intrinsicWidth <= 0) null
    else {
        val w = 540
        val h = (w.toFloat() * d.intrinsicHeight / d.intrinsicWidth).toInt().coerceAtLeast(1)
        d.toBitmap(w, h).asImageBitmap()
    }
} catch (_: Throwable) {
    null
}
