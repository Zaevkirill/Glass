package com.example.glasslock

import android.app.KeyguardManager
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val palette = listOf(
    0xFFFFFFFF, 0xFFFFE9B8, 0xFFFFD60A, 0xFFFF9F0A, 0xFFFF453A, 0xFFFF6FAE, 0xFFBF5AF2,
    0xFF5E5CE6, 0xFF64D2FF, 0xFF63E6E2, 0xFF30D158, 0xFF8E8E93, 0xFF000000
).map { it.toInt() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    style: ClockStyle,
    onStyleChange: (ClockStyle) -> Unit,
    ticker: TimeTicker,
    status: PermissionStatus,
    lockEnabled: Boolean,
    onApply: () -> Unit,
    onDisable: () -> Unit,
    onPreview: () -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onNotifications: () -> Unit,
    onWallpaper: () -> Unit
) {
    val ctx = LocalContext.current
    val wallpaper by produceState<ImageBitmap?>(null, status.wallpaper) {
        value = withContext(Dispatchers.IO) { loadWallpaper(ctx) }
    }
    val textLayout = style.layout <= 2
    val needColor2 = style.fill == 2 || style.fill == 3 || style.fill == 6 || style.layout >= 3

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF101114))
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Glass Lock", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(
            "Экран блокировки в стиле iOS. Обои — ваши системные.",
            color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp
        )

        // ---- Предпросмотр ----
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .fillMaxWidth(0.62f)
                    .aspectRatio(9f / 19f)
                    .clip(RoundedCornerShape(30.dp))
                    .border(2.dp, Color(0x33FFFFFF), RoundedCornerShape(30.dp))
            ) {
                val wp = wallpaper
                if (wp != null) {
                    Image(
                        bitmap = wp, contentDescription = null,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(listOf(Color(0xFF4B6CB7), Color(0xFF182848)))
                            )
                    )
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = style.dim)))
                IosClock(
                    style = style,
                    now = ticker.now,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = (40f + style.topOffset * 0.5f).dp),
                    sizeFactor = 0.5f
                )
                if (style.showBattery) {
                    BatteryIndicator(
                        style, ticker.now,
                        Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 12.dp),
                        sizeFactor = 0.6f
                    )
                }
                if (style.fingerprint) {
                    FingerprintButton(
                        style, true, {},
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp),
                        sizeFactor = 0.5f
                    )
                }
            }
        }

        Section("Готовые стили") {
            Chips(ClockPresets.all.map { it.first }, -1) {
                onStyleChange(
                    ClockPresets.all[it].second.copy(
                        faceUnlock = style.faceUnlock, faceDelay = style.faceDelay,
                        showBattery = style.showBattery, batteryPercent = style.batteryPercent,
                        batteryStyle = style.batteryStyle, fingerprint = style.fingerprint,
                        fpStyle = style.fpStyle, fpAnim = style.fpAnim, fpSize = style.fpSize
                    )
                )
            }
        }

        Section("Тип часов") {
            Chips(ClockNames.layouts, style.layout) { onStyleChange(style.copy(layout = it)) }
        }

        Section("Размер и форма") {
            if (textLayout) {
                SwitchRow("Растянуть до самого низа экрана", style.stretchBottom) {
                    onStyleChange(style.copy(stretchBottom = it))
                }
                if (style.stretchBottom) {
                    SliderRow("Отступ от низа", style.bottomMargin, 0f..300f) {
                        onStyleChange(style.copy(bottomMargin = it))
                    }
                }
            }
            if (!(textLayout && style.stretchBottom)) {
                SliderRow("Высота (растягивается вниз)", style.height, 0.5f..4f) { onStyleChange(style.copy(height = it)) }
            }
            SliderRow("Ширина", style.width, 0.5f..1.6f) { onStyleChange(style.copy(width = it)) }
            SliderRow("Размер", style.size, 0.5f..1.6f) { onStyleChange(style.copy(size = it)) }
            SliderRow("Толщина", style.weight, 0f..1f) { onStyleChange(style.copy(weight = it)) }
            if (textLayout) {
                SliderRow("Расстояние между цифрами", style.tracking, -0.1f..0.5f) { onStyleChange(style.copy(tracking = it)) }
                SliderRow("Наклон", style.skew, -0.4f..0.5f) { onStyleChange(style.copy(skew = it)) }
            }
            if (style.layout == 0 || style.layout == 2) {
                SliderRow("Расстояние между строками", style.lineGap, 0f..0.6f) { onStyleChange(style.copy(lineGap = it)) }
            }
        }

        if (style.layout <= 3) {
            Section("Шрифт") {
                Chips(ClockFonts.all.map { it.title }, style.fontIndex) { onStyleChange(style.copy(fontIndex = it)) }
            }
        }

        Section("Заливка и эффекты") {
            Chips(ClockNames.fills, style.fill) { onStyleChange(style.copy(fill = it)) }
            if (style.fill == 1) {
                SliderRow("Толщина контура", style.outline, 0.005f..0.12f) { onStyleChange(style.copy(outline = it)) }
            }
            if (style.fill == 3) {
                SliderRow("Свечение", style.glow, 0f..1f) { onStyleChange(style.copy(glow = it)) }
            }
            if (style.fill == 4) {
                SliderRow("Тень", style.shadow, 0f..1f) { onStyleChange(style.copy(shadow = it)) }
            }
        }

        Section("Цвета") {
            Text("Цвет 1", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            ColorPicker(style.color1) { onStyleChange(style.copy(color1 = it)) }
            if (needColor2) {
                Text("Цвет 2 (градиент, свечение, акцент)", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                ColorPicker(style.color2) { onStyleChange(style.copy(color2 = it)) }
            }
            SliderRow("Прозрачность", style.alpha, 0.2f..1f) { onStyleChange(style.copy(alpha = it)) }
        }

        Section("Время") {
            Chips(ClockNames.hourModes, style.hourMode) { onStyleChange(style.copy(hourMode = it)) }
            if (textLayout) {
                SwitchRow("Ноль перед часом (09)", style.leadingZero) { onStyleChange(style.copy(leadingZero = it)) }
            }
            SwitchRow("Показывать секунды", style.showSeconds) { onStyleChange(style.copy(showSeconds = it)) }
            if (style.layout == 1) {
                SwitchRow("Двоеточие", style.showColon) { onStyleChange(style.copy(showColon = it)) }
            }
        }

        Section("Дата") {
            SwitchRow("Показывать дату", style.showDate) { onStyleChange(style.copy(showDate = it)) }
            if (style.showDate) {
                Chips(ClockNames.datePos, style.datePos) { onStyleChange(style.copy(datePos = it)) }
                Chips(ClockNames.dateFormats, style.dateFormat) { onStyleChange(style.copy(dateFormat = it)) }
                SliderRow("Размер даты", style.dateSize, 0.6f..1.8f) { onStyleChange(style.copy(dateSize = it)) }
            }
        }

        Section("Положение и фон") {
            Chips(ClockNames.aligns, style.align) { onStyleChange(style.copy(align = it)) }
            SliderRow("Отступ сверху", style.topOffset, 0f..400f) { onStyleChange(style.copy(topOffset = it)) }
            SliderRow("Затемнение фона", style.dim, 0f..0.7f) { onStyleChange(style.copy(dim = it)) }
            SwitchRow("Подсказка «Проведите вверх»", style.showHint) { onStyleChange(style.copy(showHint = it)) }
        }

        Section("Отпечаток пальца") {
            SwitchRow("Кнопка отпечатка на экране блокировки", style.fingerprint) {
                onStyleChange(style.copy(fingerprint = it))
            }
            if (style.fingerprint) {
                Text("Стиль", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                Chips(ClockNames.fpStyles, style.fpStyle) { onStyleChange(style.copy(fpStyle = it)) }
                Text("Анимация", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                Chips(ClockNames.fpAnims, style.fpAnim) { onStyleChange(style.copy(fpAnim = it)) }
                SliderRow("Размер кнопки", style.fpSize, 0.7f..1.6f) { onStyleChange(style.copy(fpSize = it)) }
            }
            val fp = Permissions.fingerprintStatus(ctx)
            Text(
                when (fp) {
                    2 -> "✓ Отпечаток добавлен в телефоне"
                    1 -> "✗ Отпечатки в телефоне не добавлены"
                    else -> "✗ Сканер отпечатка не найден"
                },
                color = if (fp == 2) Color(0xFF30D158) else Color(0xFFFF9F0A),
                fontSize = 13.sp
            )
            if (fp > 0) {
                OutlinedButton(
                    onClick = { Permissions.openFingerprintEnroll(ctx) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) { Text(if (fp == 2) "Добавить ещё отпечаток" else "Настроить отпечаток") }
            }
            Text(
                "Отпечаток записывает и проверяет сама система телефона: так устроен Android, приложение " +
                    "не получает доступ к вашим отпечаткам. Нажмите кнопку на экране блокировки и " +
                    "приложите палец к сканеру.",
                color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp
            )
        }

        Section("Батарея") {
            SwitchRow("Показывать заряд в правом верхнем углу", style.showBattery) {
                onStyleChange(style.copy(showBattery = it))
            }
            if (style.showBattery) {
                Chips(ClockNames.batteryStyles, style.batteryStyle) { onStyleChange(style.copy(batteryStyle = it)) }
                if (style.batteryStyle != 2) {
                    SwitchRow("Показывать проценты", style.batteryPercent) {
                        onStyleChange(style.copy(batteryPercent = it))
                    }
                }
            }
        }

        Section("Разблокировка по лицу") {
            SwitchRow("Открывать проверку лица автоматически", style.faceUnlock) {
                onStyleChange(style.copy(faceUnlock = it))
            }
            if (style.faceUnlock) {
                SliderRow("Задержка перед запросом, сек", style.faceDelay, 0f..2f) {
                    onStyleChange(style.copy(faceDelay = it))
                }
            }
            val secure = ctx.getSystemService(KeyguardManager::class.java).isDeviceSecure
            Text(
                if (secure) "✓ В телефоне настроена защита (PIN / лицо)"
                else "✗ Защита экрана в телефоне не настроена: автооткрытие отключено, иначе экран открывался бы сам",
                color = if (secure) Color(0xFF30D158) else Color(0xFFFF9F0A),
                fontSize = 13.sp
            )
            Text(
                "Лицо распознаёт сама система телефона, приложение камеру не использует. " +
                    "Разблокировка по лицу должна быть включена в настройках телефона.",
                color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp
            )
        }

        Section("Разрешения") {
            PermRow("Поверх других окон", status.overlay, onOverlay)
            PermRow("Уведомления (для службы)", status.notifications, onNotifications)
            PermRow("Без оптимизации батареи", status.battery, onBattery)
            PermRow("Доступ к обоям (для предпросмотра)", status.wallpaper, onWallpaper)
        }

        Button(
            onClick = onApply,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                if (lockEnabled) "Применить заново" else "Применить по умолчанию",
                fontSize = 16.sp, fontWeight = FontWeight.SemiBold
            )
        }
        OutlinedButton(
            onClick = onPreview,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Предпросмотр экрана блокировки") }
        if (lockEnabled) {
            OutlinedButton(
                onClick = onDisable,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Выключить экран блокировки") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Surface(color = Color(0xFF1C1D22), shape = RoundedCornerShape(20.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Chips(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, t ->
            FilterChip(
                selected = i == selected,
                onClick = { onSelect(i) },
                label = { Text(t) }
            )
        }
    }
}

@Composable
private fun ColorPicker(selected: Int, onPick: (Int) -> Unit) {
    var hue by remember { mutableFloatStateOf(200f) }
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        palette.forEach { c ->
            val isSel = selected == c
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        if (isSel) 3.dp else 1.dp,
                        if (isSel) Color(0xFF64D2FF) else Color(0x55FFFFFF),
                        CircleShape
                    )
                    .clickable { onPick(c) }
            )
        }
    }
    Text("Свой оттенок", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
    Slider(
        value = hue,
        onValueChange = {
            hue = it
            onPick(AndroidColor.HSVToColor(floatArrayOf(it, 0.75f, 1f)))
        },
        valueRange = 0f..360f
    )
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Row {
            Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("%.2f".format(value), color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 14.sp,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        )
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PermRow(label: String, granted: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            (if (granted) "✓ " else "✗ ") + label,
            color = if (granted) Color(0xFF30D158) else Color(0xFFFF9F0A),
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
        )
        if (!granted) TextButton(onClick = onClick) { Text("Выдать") }
    }
}

/** Системные обои для предпросмотра. Без разрешения вернёт null (будет градиент). */
private fun loadWallpaper(ctx: Context): ImageBitmap? = try {
    val d = WallpaperManager.getInstance(ctx).drawable
    if (d == null || d.intrinsicWidth <= 0) null
    else {
        val w = 540
        val h = (w.toFloat() * d.intrinsicHeight / d.intrinsicWidth).toInt().coerceAtLeast(1)
        d.toBitmap(w, h).asImageBitmap()
    }
} catch (_: Throwable) {
    null
}
