package com.example.glasslock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/* ======================= Батарея ======================= */

data class BatteryInfo(val percent: Int, val charging: Boolean)

private fun readBattery(i: Intent?): BatteryInfo {
    if (i == null) return BatteryInfo(100, false)
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val pct = if (level >= 0 && scale > 0) level * 100 / scale else 100
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    return BatteryInfo(pct.coerceIn(0, 100), charging)
}

/** Системный заряд батареи в правом верхнем углу. */
@Composable
fun BatteryIndicator(
    style: ClockStyle,
    now: Long,
    modifier: Modifier = Modifier,
    sizeFactor: Float = 1f
) {
    val ctx = LocalContext.current
    val filter = remember { IntentFilter(Intent.ACTION_BATTERY_CHANGED) }
    var info by remember { mutableStateOf(readBattery(ctx.registerReceiver(null, filter))) }

    // обновляем при каждом пробуждении/тике времени
    LaunchedEffect(now) { info = readBattery(ctx.registerReceiver(null, filter)) }

    DisposableEffect(ctx) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                info = readBattery(i)
            }
        }
        ContextCompat.registerReceiver(ctx, r, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose {
            try {
                ctx.unregisterReceiver(r)
            } catch (_: IllegalArgumentException) {
            }
        }
    }

    val f = sizeFactor
    val base = Color(style.color1).copy(alpha = style.alpha)
    val level = when {
        info.charging -> Color(0xFF30D158)
        info.percent <= 20 -> Color(0xFFFF453A)
        else -> base
    }
    val pulse = rememberInfiniteTransition(label = "bat")
    val boltAlpha = pulse.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "bolt"
    )

    Row(
        modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((5f * f).dp)
    ) {
        if (info.charging) {
            Text("⚡", fontSize = (12f * f).sp, color = level, modifier = Modifier.graphicsLayer { alpha = boltAlpha.value })
        }
        when (style.batteryStyle) {
            2 -> Text(
                "${info.percent}%", color = level,
                fontSize = (14f * f).sp, fontWeight = FontWeight.SemiBold
            )
            1 -> {
                if (style.batteryPercent) {
                    Text(
                        "${info.percent}%", color = base,
                        fontSize = (13f * f).sp, fontWeight = FontWeight.SemiBold
                    )
                }
                Canvas(Modifier.size((18f * f).dp)) {
                    val w = size.minDimension * 0.16f
                    val inset = w / 2f
                    drawArc(
                        color = base.copy(alpha = 0.25f), startAngle = 0f, sweepAngle = 360f,
                        useCenter = false, topLeft = Offset(inset, inset),
                        size = Size(size.width - w, size.height - w), style = Stroke(w)
                    )
                    drawArc(
                        color = level, startAngle = -90f, sweepAngle = 360f * info.percent / 100f,
                        useCenter = false, topLeft = Offset(inset, inset),
                        size = Size(size.width - w, size.height - w),
                        style = Stroke(w, cap = StrokeCap.Round)
                    )
                }
            }
            else -> {
                if (style.batteryPercent) {
                    Text(
                        "${info.percent}%", color = base,
                        fontSize = (13f * f).sp, fontWeight = FontWeight.SemiBold
                    )
                }
                Canvas(Modifier.size((29f * f).dp, (13f * f).dp)) {
                    val h = size.height
                    val bodyW = size.width - h * 0.25f
                    val sw = h * 0.09f
                    drawRoundRect(
                        color = base.copy(alpha = 0.45f),
                        topLeft = Offset(sw / 2f, sw / 2f),
                        size = Size(bodyW - sw, h - sw),
                        cornerRadius = CornerRadius(h * 0.3f),
                        style = Stroke(sw)
                    )
                    val inset = sw * 2f
                    val fillW = (bodyW - inset * 2f) * info.percent / 100f
                    drawRoundRect(
                        color = level,
                        topLeft = Offset(inset, inset),
                        size = Size(max(fillW, h * 0.1f), h - inset * 2f),
                        cornerRadius = CornerRadius(h * 0.18f)
                    )
                    drawRoundRect(
                        color = base.copy(alpha = 0.45f),
                        topLeft = Offset(bodyW + sw, h * 0.32f),
                        size = Size(h * 0.14f, h * 0.36f),
                        cornerRadius = CornerRadius(h * 0.07f)
                    )
                }
            }
        }
    }
}
