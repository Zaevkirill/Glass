package com.example.glasslock

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

data class PermissionStatus(
    val overlay: Boolean,
    val battery: Boolean,
    val notifications: Boolean,
    val wallpaper: Boolean
)

object Permissions {

    fun canOverlay(c: Context) = Settings.canDrawOverlays(c)

    fun ignoresBattery(c: Context): Boolean =
        c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)

    fun notificationsGranted(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun storagePermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun wallpaperGranted(c: Context): Boolean =
        ContextCompat.checkSelfPermission(c, storagePermission()) == PackageManager.PERMISSION_GRANTED

    fun status(c: Context) = PermissionStatus(
        overlay = canOverlay(c),
        battery = ignoresBattery(c),
        notifications = notificationsGranted(c),
        wallpaper = wallpaperGranted(c)
    )

    fun overlayIntent(c: Context) = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${c.packageName}")
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    @SuppressLint("BatteryLife")
    fun batteryIntent(c: Context) = Intent(
        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
        Uri.parse("package:${c.packageName}")
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun batteryFallbackIntent() =
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
