package com.example.glasslock

import android.content.Context
import android.graphics.Typeface
import android.os.Build

/** Все настройки внешнего вида часов. */
data class ClockStyle(
    val height: Float = 1.15f,          // scaleY: 0.6 .. 2.0
    val width: Float = 1.0f,            // scaleX: 0.6 .. 1.5
    val weight: Float = 0.6f,           // толщина 0 .. 1
    val colorArgb: Int = 0xFFFFFFFF.toInt(),
    val alpha: Float = 0.92f,           // прозрачность текста 0.2 .. 1
    val fontIndex: Int = 0,
    val stacked: Boolean = true,        // часы над минутами как в iOS
    val showDate: Boolean = true
)

data class ClockFont(val title: String, val family: String)

object ClockFonts {
    val all = listOf(
        ClockFont("Системный", "sans-serif"),
        ClockFont("Узкий", "sans-serif-condensed"),
        ClockFont("Серифный", "serif"),
        ClockFont("Моно", "monospace"),
        ClockFont("Casual", "casual"),
        ClockFont("Курсив", "cursive")
    )

    fun typeface(index: Int, weight: Float): Typeface {
        val family = all.getOrElse(index) { all[0] }.family
        val base = Typeface.create(family, Typeface.NORMAL)
        val w = (100 + 800 * weight).toInt().coerceIn(100, 900)
        return if (Build.VERSION.SDK_INT >= 28) {
            Typeface.create(base, w, false)
        } else {
            if (weight > 0.55f) Typeface.create(base, Typeface.BOLD) else base
        }
    }
}

class ClockStyleStore(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("clock_style", Context.MODE_PRIVATE)

    fun load(): ClockStyle {
        val d = ClockStyle()
        return ClockStyle(
            height = prefs.getFloat("height", d.height),
            width = prefs.getFloat("width", d.width),
            weight = prefs.getFloat("weight", d.weight),
            colorArgb = prefs.getInt("color", d.colorArgb),
            alpha = prefs.getFloat("alpha", d.alpha),
            fontIndex = prefs.getInt("font", d.fontIndex),
            stacked = prefs.getBoolean("stacked", d.stacked),
            showDate = prefs.getBoolean("showDate", d.showDate)
        )
    }

    fun save(s: ClockStyle) {
        prefs.edit()
            .putFloat("height", s.height)
            .putFloat("width", s.width)
            .putFloat("weight", s.weight)
            .putInt("color", s.colorArgb)
            .putFloat("alpha", s.alpha)
            .putInt("font", s.fontIndex)
            .putBoolean("stacked", s.stacked)
            .putBoolean("showDate", s.showDate)
            .apply()
    }

    var lockEnabled: Boolean
        get() = prefs.getBoolean("lock_enabled", false)
        set(value) {
            prefs.edit().putBoolean("lock_enabled", value).apply()
        }
}
