package com.example.glasslock

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import org.json.JSONObject

/** Все настройки внешнего вида часов. */
data class ClockStyle(
    val layout: Int = 0,            // 0 стопка, 1 строка, 2 вертикальные цифры, 3 аналоговые, 4 бинарные
    val height: Float = 1.15f,      // растяжение по вертикали (вниз)
    val width: Float = 1.0f,
    val size: Float = 1.0f,
    val weight: Float = 0.6f,
    val tracking: Float = 0f,       // расстояние между буквами
    val lineGap: Float = 0.14f,     // расстояние между строками
    val skew: Float = 0f,           // наклон (курсив)
    val fontIndex: Int = 0,
    val fill: Int = 0,              // 0 сплошной, 1 контур, 2 градиент, 3 неон, 4 тень, 5 стекло, 6 два цвета
    val color1: Int = 0xFFFFFFFF.toInt(),
    val color2: Int = 0xFF64D2FF.toInt(),
    val alpha: Float = 0.92f,
    val outline: Float = 0.03f,
    val glow: Float = 0.5f,
    val shadow: Float = 0.5f,
    val hourMode: Int = 0,          // 0 системный, 1 24ч, 2 12ч
    val leadingZero: Boolean = true,
    val showSeconds: Boolean = false,
    val showColon: Boolean = true,
    val showDate: Boolean = true,
    val datePos: Int = 0,           // 0 сверху, 1 снизу
    val dateFormat: Int = 0,
    val dateSize: Float = 1f,
    val align: Int = 0,             // 0 центр, 1 слева, 2 справа
    val topOffset: Float = 0f,
    val dim: Float = 0.22f,
    val showHint: Boolean = true,
    val stretchBottom: Boolean = false, // растянуть часы до низа экрана
    val bottomMargin: Float = 0f,       // отступ от низа, dp
    val faceUnlock: Boolean = false, // автозапрос системной разблокировки (лицо) при включении экрана
    val faceDelay: Float = 0.4f,     // задержка перед запросом, сек
    val showBattery: Boolean = true,
    val batteryPercent: Boolean = true,
    val batteryStyle: Int = 0,       // 0 значок, 1 кольцо, 2 только процент
    val fingerprint: Boolean = true, // кнопка отпечатка на экране блокировки
    val fpStyle: Int = 0,            // 0 стекло, 1 контур, 2 неон, 3 минимал
    val fpAnim: Int = 1,             // 0 нет, 1 пульс, 2 волны, 3 дыхание, 4 сканирование
    val fpSize: Float = 1f
)

object ClockNames {
    val layouts = listOf("Стопка (iOS)", "Одна строка", "Вертикальные цифры", "Аналоговые", "Бинарные")
    val fills = listOf("Сплошной", "Контур", "Градиент", "Неон", "Тень", "Стекло", "Два цвета")
    val hourModes = listOf("Как в системе", "24 часа", "12 часов")
    val dateFormats = listOf("Понедельник, 15 ноября", "Пн, 15 нояб.", "15.11.2026", "15 ноября", "Понедельник")
    val datePos = listOf("Сверху", "Снизу")
    val aligns = listOf("По центру", "Слева", "Справа")
    val fpStyles = listOf("Стекло", "Контур", "Неон", "Минимал")
    val fpAnims = listOf("Без анимации", "Пульс", "Волны", "Дыхание", "Сканирование")
    val batteryStyles = listOf("Значок", "Кольцо", "Только процент")
}

private fun c(v: Long) = v.toInt()

object ClockPresets {
    val all: List<Pair<String, ClockStyle>> = listOf(
        "iOS классика" to ClockStyle(),
        "Тонкий" to ClockStyle(weight = 0.05f, height = 1.3f, color1 = c(0xFFFFE9B8)),
        "Жирный" to ClockStyle(weight = 1f, width = 1.1f, height = 1.0f),
        "Высокая строка" to ClockStyle(layout = 1, height = 3.2f, width = 0.8f, weight = 0.7f),
        "Во весь экран" to ClockStyle(layout = 1, stretchBottom = true, width = 1.1f, weight = 0.85f),
        "Узкие высокие" to ClockStyle(fontIndex = 1, height = 2.0f, width = 0.85f, weight = 0.7f),
        "Неон" to ClockStyle(fill = 3, color2 = c(0xFFFF2D95), weight = 0.4f, glow = 0.9f),
        "Контур" to ClockStyle(fill = 1, weight = 0f, outline = 0.035f, height = 1.3f),
        "Закат" to ClockStyle(fill = 2, color1 = c(0xFFFFD60A), color2 = c(0xFFFF375F), weight = 0.9f),
        "Ретро" to ClockStyle(
            layout = 1, fill = 4, fontIndex = 3, color1 = c(0xFF30D158),
            weight = 0.7f, shadow = 0.8f, tracking = 0.05f, size = 0.95f
        ),
        "Стекло" to ClockStyle(fill = 5, weight = 0.9f, height = 1.1f),
        "Два цвета" to ClockStyle(fill = 6, color2 = c(0xFFFF9F0A), weight = 0.8f),
        "Курсив" to ClockStyle(layout = 1, fontIndex = 2, skew = 0.25f, height = 1.4f, weight = 0.3f),
        "Вертикальные" to ClockStyle(layout = 2, weight = 0.5f, size = 0.8f, lineGap = 0.1f),
        "Аналоговые" to ClockStyle(layout = 3, weight = 0.5f),
        "Бинарные" to ClockStyle(layout = 4, color1 = c(0xFF64D2FF), color2 = c(0xFFBF5AF2))
    )
}

data class ClockFont(val title: String, val family: String)

object ClockFonts {
    val all = listOf(
        ClockFont("Системный", "sans-serif"),
        ClockFont("Узкий", "sans-serif-condensed"),
        ClockFont("Серифный", "serif"),
        ClockFont("Моно", "monospace"),
        ClockFont("Casual", "casual"),
        ClockFont("Курсив", "cursive")
    )

    private val cache = HashMap<Int, Typeface>()

    /** Шрифты кэшируются, чтобы первый кадр рисовался без задержки. */
    fun typeface(index: Int, weight: Float): Typeface = synchronized(cache) {
        cache.getOrPut(index * 1000 + (weight * 100).toInt()) { create(index, weight) }
    }

    private fun create(index: Int, weight: Float): Typeface {
        val family = all.getOrElse(index) { all[0] }.family
        val base = Typeface.create(family, Typeface.NORMAL)
        val w = (100 + 800 * weight).toInt().coerceIn(100, 900)
        return if (Build.VERSION.SDK_INT >= 28) {
            Typeface.create(base, w, false)
        } else {
            if (weight > 0.55f) Typeface.create(base, Typeface.BOLD) else base
        }
    }
}

private fun ClockStyle.toJson(): String = JSONObject().apply {
    put("layout", layout); put("height", height.toDouble()); put("width", width.toDouble())
    put("size", size.toDouble()); put("weight", weight.toDouble())
    put("tracking", tracking.toDouble()); put("lineGap", lineGap.toDouble()); put("skew", skew.toDouble())
    put("fontIndex", fontIndex); put("fill", fill)
    put("color1", color1); put("color2", color2); put("alpha", alpha.toDouble())
    put("outline", outline.toDouble()); put("glow", glow.toDouble()); put("shadow", shadow.toDouble())
    put("hourMode", hourMode); put("leadingZero", leadingZero)
    put("showSeconds", showSeconds); put("showColon", showColon)
    put("showDate", showDate); put("datePos", datePos); put("dateFormat", dateFormat)
    put("dateSize", dateSize.toDouble())
    put("align", align); put("topOffset", topOffset.toDouble()); put("dim", dim.toDouble())
    put("showHint", showHint)
    put("stretchBottom", stretchBottom); put("bottomMargin", bottomMargin.toDouble())
    put("faceUnlock", faceUnlock); put("faceDelay", faceDelay.toDouble())
    put("showBattery", showBattery); put("batteryPercent", batteryPercent); put("batteryStyle", batteryStyle)
    put("fingerprint", fingerprint); put("fpStyle", fpStyle); put("fpAnim", fpAnim); put("fpSize", fpSize.toDouble())
}.toString()

private fun styleFromJson(s: String?): ClockStyle {
    val d = ClockStyle()
    if (s.isNullOrEmpty()) return d
    return try {
        val j = JSONObject(s)
        fun f(k: String, def: Float) = j.optDouble(k, def.toDouble()).toFloat()
        ClockStyle(
            layout = j.optInt("layout", d.layout),
            height = f("height", d.height),
            width = f("width", d.width),
            size = f("size", d.size),
            weight = f("weight", d.weight),
            tracking = f("tracking", d.tracking),
            lineGap = f("lineGap", d.lineGap),
            skew = f("skew", d.skew),
            fontIndex = j.optInt("fontIndex", d.fontIndex),
            fill = j.optInt("fill", d.fill),
            color1 = j.optInt("color1", d.color1),
            color2 = j.optInt("color2", d.color2),
            alpha = f("alpha", d.alpha),
            outline = f("outline", d.outline),
            glow = f("glow", d.glow),
            shadow = f("shadow", d.shadow),
            hourMode = j.optInt("hourMode", d.hourMode),
            leadingZero = j.optBoolean("leadingZero", d.leadingZero),
            showSeconds = j.optBoolean("showSeconds", d.showSeconds),
            showColon = j.optBoolean("showColon", d.showColon),
            showDate = j.optBoolean("showDate", d.showDate),
            datePos = j.optInt("datePos", d.datePos),
            dateFormat = j.optInt("dateFormat", d.dateFormat),
            dateSize = f("dateSize", d.dateSize),
            align = j.optInt("align", d.align),
            topOffset = f("topOffset", d.topOffset),
            dim = f("dim", d.dim),
            showHint = j.optBoolean("showHint", d.showHint),
            stretchBottom = j.optBoolean("stretchBottom", d.stretchBottom),
            bottomMargin = f("bottomMargin", d.bottomMargin),
            faceUnlock = j.optBoolean("faceUnlock", d.faceUnlock),
            faceDelay = f("faceDelay", d.faceDelay),
            showBattery = j.optBoolean("showBattery", d.showBattery),
            batteryPercent = j.optBoolean("batteryPercent", d.batteryPercent),
            batteryStyle = j.optInt("batteryStyle", d.batteryStyle),
            fingerprint = j.optBoolean("fingerprint", d.fingerprint),
            fpStyle = j.optInt("fpStyle", d.fpStyle),
            fpAnim = j.optInt("fpAnim", d.fpAnim),
            fpSize = f("fpSize", d.fpSize)
        )
    } catch (_: Exception) {
        d
    }
}

class ClockStyleStore(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("clock_style", Context.MODE_PRIVATE)

    /** Стиль держим в памяти: окно блокировки читает его мгновенно, без разбора файла. */
    fun load(): ClockStyle =
        cached ?: styleFromJson(prefs.getString("style_json", null)).also { cached = it }

    fun save(s: ClockStyle) {
        cached = s
        prefs.edit().putString("style_json", s.toJson()).apply()
    }

    companion object {
        @Volatile
        private var cached: ClockStyle? = null
    }

    var lockEnabled: Boolean
        get() = prefs.getBoolean("lock_enabled", false)
        set(value) {
            prefs.edit().putBoolean("lock_enabled", value).apply()
        }
}
