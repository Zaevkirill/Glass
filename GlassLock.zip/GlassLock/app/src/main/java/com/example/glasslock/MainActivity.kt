package com.example.glasslock

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {

    private lateinit var store: ClockStyleStore
    private lateinit var ticker: TimeTicker

    private var refresh by mutableIntStateOf(0)
    private var lockEnabled by mutableStateOf(false)

    private var applying = false
    private val asked = mutableSetOf<String>()

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }

    private val wallpaperLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        store = ClockStyleStore(this)
        ticker = TimeTicker(this)
        lockEnabled = store.lockEnabled

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF64D2FF),
                    background = Color(0xFF101114),
                    surface = Color(0xFF1C1D22)
                )
            ) {
                var style by remember { mutableStateOf(store.load()) }
                val status = remember(refresh) { Permissions.status(this@MainActivity) }

                SettingsScreen(
                    style = style,
                    onStyleChange = {
                        style = it
                        store.save(it)
                    },
                    ticker = ticker,
                    status = status,
                    lockEnabled = lockEnabled,
                    onApply = { startApply() },
                    onDisable = { disableLock() },
                    onPreview = {
                        startActivity(Intent(this, LockScreenActivity::class.java))
                    },
                    onOverlay = { startActivity(Permissions.overlayIntent(this)) },
                    onBattery = { requestBattery() },
                    onNotifications = {
                        if (Build.VERSION.SDK_INT >= 33) {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onWallpaper = { wallpaperLauncher.launch(Permissions.storagePermission()) }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        ticker.register()
    }

    override fun onResume() {
        super.onResume()
        ticker.refresh()
        refresh++
        if (applying) continueApply()   // продолжаем цепочку после возврата из настроек
    }

    override fun onStop() {
        ticker.unregister()
        super.onStop()
    }

    private fun startApply() {
        asked.clear()
        applying = true
        continueApply()
    }

    /** Проверяет и по очереди запрашивает всё нужное, затем включает локскрин. */
    private fun continueApply() {
        if (!Permissions.canOverlay(this)) {
            if ("overlay" in asked) {
                applying = false
                toast("Без разрешения «Поверх других окон» экран блокировки работать не будет")
                return
            }
            asked += "overlay"
            toast("Включите «Поверх других окон» для Glass Lock")
            startActivity(Permissions.overlayIntent(this))
            return
        }
        if (!Permissions.notificationsGranted(this) && "notif" !in asked) {
            asked += "notif"
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        if (!Permissions.ignoresBattery(this) && "battery" !in asked) {
            asked += "battery"
            requestBattery()
            return
        }

        applying = false
        asked.clear()
        store.lockEnabled = true
        lockEnabled = true
        LockScreenService.start(this)
        toast("Экран блокировки включён. Выключите и включите экран для проверки")
    }

    private fun requestBattery() {
        try {
            startActivity(Permissions.batteryIntent(this))
        } catch (_: Exception) {
            startActivity(Permissions.batteryFallbackIntent())
        }
    }

    private fun disableLock() {
        applying = false
        store.lockEnabled = false
        lockEnabled = false
        LockScreenService.stop(this)
        toast("Экран блокировки выключен")
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
