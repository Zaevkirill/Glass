package com.example.glasslock

import android.app.KeyguardManager
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Foreground Service: слушает ACTION_SCREEN_OFF / ACTION_SCREEN_ON
 * и поднимает окно блокировки поверх системного экрана.
 */
class LockScreenService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val recheck = Runnable { if (!LockScreenActivity.isForeground) showLock() }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                // готовим окно заранее, пока экран гаснет
                Intent.ACTION_SCREEN_OFF -> showLock()
                Intent.ACTION_SCREEN_ON -> {
                    if (!LockScreenActivity.isForeground) showLock()
                    // страховка: если первый запуск не сработал — повторяем
                    handler.removeCallbacks(recheck)
                    handler.postDelayed(recheck, 120L)
                    handler.postDelayed(recheck, 450L)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(
            this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // после загрузки телефона сразу показываем наш экран вместо системного
        if (intent?.getBooleanExtra(EXTRA_SHOW_NOW, false) == true &&
            getSystemService(KeyguardManager::class.java).isKeyguardLocked
        ) {
            showLock()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: IllegalArgumentException) {
        }
        super.onDestroy()
    }

    private fun showLock() {
        // SYSTEM_ALERT_WINDOW даёт право запускать активность из фона (Android 10+)
        if (!Permissions.canOverlay(this)) return
        try {
            val i = Intent(this, LockScreenActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
            startActivity(i, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle())
        } catch (_: Exception) {
        }
    }

    private fun createChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "Экран блокировки", NotificationManager.IMPORTANCE_MIN
        ).apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Экран блокировки активен")
            .setContentText("Нажмите, чтобы открыть настройки")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "lock_service"
        private const val NOTIFICATION_ID = 4242
        private const val EXTRA_SHOW_NOW = "show_now"

        fun start(context: Context, showNow: Boolean = false) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, LockScreenService::class.java).putExtra(EXTRA_SHOW_NOW, showNow)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, LockScreenService::class.java))
            LockScreenActivity.instance?.finishAndRemoveTask()
        }
    }
}
