package com.example.glasslock

import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

/** Дата над часами + цифры с настраиваемой высотой/шириной/толщиной. */
@Composable
fun IosClock(
    style: ClockStyle,
    hours: String,
    minutes: String,
    date: String,
    modifier: Modifier = Modifier,
    sizeFactor: Float = 1f
) {
    val density = LocalDensity.current
    BoxWithConstraints(modifier, contentAlignment = Alignment.TopCenter) {
        val maxPx = with(density) { maxWidth.toPx() } * 0.94f
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (style.showDate) {
                Text(
                    text = date,
                    color = Color(style.colorArgb)
                        .copy(alpha = (style.alpha * 0.9f).coerceIn(0f, 1f)),
                    fontSize = (21f * sizeFactor).sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
                Spacer(Modifier.height((4f * sizeFactor).dp))
            }
            val lines = if (style.stacked) listOf(hours, minutes) else listOf("$hours:$minutes")
            val textPx = with(density) { (if (style.stacked) 128.sp else 90.sp).toPx() } * sizeFactor
            ClockDigits(style, lines, textPx, maxPx)
        }
    }
}

@Composable
private fun ClockDigits(
    style: ClockStyle,
    lines: List<String>,
    textPx: Float,
    maxWidthPx: Float
) {
    val density = LocalDensity.current
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    val bounds = remember { Rect() }
    val typeface = remember(style.fontIndex, style.weight) {
        ClockFonts.typeface(style.fontIndex, style.weight)
    }

    paint.typeface = typeface
    paint.textSize = textPx
    paint.style = Paint.Style.FILL_AND_STROKE      // плавная «жирность» поверх веса шрифта
    paint.strokeJoin = Paint.Join.ROUND
    paint.strokeWidth = style.weight * 0.03f * textPx
    paint.textAlign = Paint.Align.CENTER
    paint.getTextBounds("0", 0, 1, bounds)

    val digitH = bounds.height().toFloat()
    val gap = digitH * 0.14f
    val stroke = paint.strokeWidth
    val contentW = lines.maxOf { paint.measureText(it) } + stroke
    val contentH = digitH * lines.size + gap * (lines.size - 1) + stroke

    // если растянутые цифры не помещаются по ширине — равномерно уменьшаем
    val fit = min(1f, maxWidthPx / (contentW * style.width))
    val sx = style.width * fit
    val sy = style.height * fit
    val color = Color(style.colorArgb).copy(alpha = style.alpha).toArgb()

    Canvas(
        Modifier.size(
            with(density) { (contentW * sx).toDp() },
            with(density) { (contentH * sy).toDp() }
        )
    ) {
        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            paint.color = color
            nc.save()
            nc.translate(size.width / 2f, size.height / 2f)
            nc.scale(sx, sy)                          // растяжение по вертикали/горизонтали
            val top = -contentH / 2f + stroke / 2f
            lines.forEachIndexed { i, line ->
                nc.drawText(line, 0f, top + digitH * (i + 1) + gap * i, paint)
            }
            nc.restore()
        }
    }
}
