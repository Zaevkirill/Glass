package com.example.glasslock

import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Shader
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private fun withAlpha(c: Int, a: Float): Int =
    (c and 0x00FFFFFF) or ((((c ushr 24) and 0xFF) * a).toInt().coerceIn(0, 255) shl 24)

private fun composeFamily(i: Int): FontFamily = when (i) {
    2 -> FontFamily.Serif
    3 -> FontFamily.Monospace
    4, 5 -> FontFamily.Cursive
    else -> FontFamily.SansSerif
}

/** Дата + часы любого из стилей. Время берётся из now (миллисекунды). */
@Composable
fun IosClock(
    style: ClockStyle,
    now: Long,
    modifier: Modifier = Modifier,
    sizeFactor: Float = 1f
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current

    // секунды тикают отдельно, только пока включены
    val t by produceState(now, now, style.showSeconds) {
        value = now
        if (style.showSeconds) {
            while (true) {
                delay(1000L - (System.currentTimeMillis() % 1000L))
                value = System.currentTimeMillis()
            }
        }
    }

    val parts = TimeFormat.parts(ctx, t, style.hourMode)
    val dateText = TimeFormat.date(t, style.dateFormat)
    val hAlign = when (style.align) {
        1 -> Alignment.Start
        2 -> Alignment.End
        else -> Alignment.CenterHorizontally
    }
    val boxAlign = when (style.align) {
        1 -> Alignment.TopStart
        2 -> Alignment.TopEnd
        else -> Alignment.TopCenter
    }

    BoxWithConstraints(modifier, contentAlignment = boxAlign) {
        val pad = if (style.align == 0) 0.dp else (24f * sizeFactor).dp
        val maxPx = with(density) { (maxWidth - pad * 2).toPx() } * 0.97f

        Column(Modifier.padding(horizontal = pad), horizontalAlignment = hAlign) {
            if (style.showDate && style.datePos == 0) {
                DateText(style, dateText, sizeFactor)
                Spacer(Modifier.height((4f * sizeFactor).dp))
            }
            when (style.layout) {
                3 -> AnalogFace(style, parts, sizeFactor, maxPx)
                4 -> BinaryFace(style, parts, sizeFactor, maxPx)
                else -> {
                    val hh = if (style.leadingZero) "%02d".format(parts.h) else parts.h.toString()
                    val mm = "%02d".format(parts.m)
                    val ss = "%02d".format(parts.s)
                    val sep = if (style.showColon) ":" else " "
                    val lines: List<String>
                    val split: Int
                    val base: Float
                    when (style.layout) {
                        1 -> {
                            lines = listOf(if (style.showSeconds) "$hh$sep$mm$sep$ss" else "$hh$sep$mm")
                            split = 1
                            base = if (style.showSeconds) 66f else 90f
                        }
                        2 -> {
                            lines = (hh + mm + (if (style.showSeconds) ss else "")).map { it.toString() }
                            split = hh.length
                            base = 96f
                        }
                        else -> {
                            lines = if (style.showSeconds) listOf(hh, mm, ss) else listOf(hh, mm)
                            split = 1
                            base = 128f
                        }
                    }
                    val textPx = with(density) { base.sp.toPx() } * style.size * sizeFactor
                    ClockDigits(style, lines, split, textPx, maxPx)
                }
            }
            if (style.showDate && style.datePos == 1) {
                Spacer(Modifier.height((6f * sizeFactor).dp))
                DateText(style, dateText, sizeFactor)
            }
        }
    }
}

@Composable
private fun DateText(style: ClockStyle, text: String, sizeFactor: Float) {
    Text(
        text = text,
        color = Color(style.color1).copy(alpha = (style.alpha * 0.9f).coerceIn(0f, 1f)),
        fontSize = (21f * style.dateSize * sizeFactor).sp,
        fontWeight = FontWeight.SemiBold,
        fontFamily = composeFamily(style.fontIndex),
        maxLines = 1
    )
}

/* ---------------- Текстовые стили (стопка / строка / вертикальные) ---------------- */

@Composable
private fun ClockDigits(
    style: ClockStyle,
    lines: List<String>,
    split: Int,
    textPx: Float,
    maxWidthPx: Float
) {
    val density = LocalDensity.current
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    val bounds = remember { Rect() }
    val typeface = remember(style.fontIndex, style.weight) {
        ClockFonts.typeface(style.fontIndex, style.weight)
    }

    val strokeSolid = style.weight * 0.03f * textPx
    paint.reset()
    paint.isAntiAlias = true
    paint.typeface = typeface
    paint.textSize = textPx
    paint.letterSpacing = style.tracking
    paint.textAlign = Paint.Align.CENTER
    paint.strokeJoin = Paint.Join.ROUND
    paint.textSkewX = -style.skew
    paint.style = Paint.Style.FILL_AND_STROKE
    paint.strokeWidth = strokeSolid
    paint.getTextBounds("0", 0, 1, bounds)

    val digitH = bounds.height().toFloat()
    val gap = digitH * style.lineGap
    val outlineW = if (style.fill == 1) max(style.outline * textPx, 1f) else strokeSolid
    val padStroke = max(strokeSolid, outlineW)
    val contentW = lines.maxOf { paint.measureText(it) } + padStroke + digitH * abs(style.skew) * 0.5f
    val contentH = digitH * lines.size + gap * (lines.size - 1) + padStroke

    // ширина ужимается только если не влезает; высота растягивается свободно (вниз)
    val sx = min(style.width, maxWidthPx / contentW)
    val sy = style.height

    Canvas(
        Modifier.size(
            with(density) { (contentW * sx).toDp() },
            with(density) { (contentH * sy).toDp() }
        )
    ) {
        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            nc.save()
            nc.translate(size.width / 2f, size.height / 2f)
            nc.scale(sx, sy)
            val top = -contentH / 2f + padStroke / 2f
            drawStyled(nc, paint, style, lines, split, top, digitH, gap, textPx, contentH, strokeSolid, outlineW)
            nc.restore()
        }
    }
}

private fun drawStyled(
    nc: android.graphics.Canvas,
    p: Paint,
    s: ClockStyle,
    lines: List<String>,
    split: Int,
    top: Float,
    digitH: Float,
    gap: Float,
    textPx: Float,
    contentH: Float,
    strokeSolid: Float,
    outlineW: Float
) {
    val c1 = withAlpha(s.color1, s.alpha)
    val c2 = withAlpha(s.color2, s.alpha)

    fun draw(colorFor: (Int) -> Int) {
        lines.forEachIndexed { i, line ->
            p.color = colorFor(i)
            nc.drawText(line, 0f, top + digitH * (i + 1) + gap * i, p)
        }
    }

    p.shader = null
    p.clearShadowLayer()
    when (s.fill) {
        1 -> { // контур
            p.style = Paint.Style.STROKE
            p.strokeWidth = outlineW
            draw { c1 }
        }
        2 -> { // градиент
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = strokeSolid
            p.shader = LinearGradient(0f, -contentH / 2f, 0f, contentH / 2f, c1, c2, Shader.TileMode.CLAMP)
            draw { 0xFFFFFFFF.toInt() }
        }
        3 -> { // неон
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = strokeSolid
            val r = (0.02f + s.glow * 0.12f) * textPx
            p.setShadowLayer(r, 0f, 0f, withAlpha(s.color2, 1f))
            draw { c1 }
            p.setShadowLayer(r * 0.4f, 0f, 0f, withAlpha(s.color2, 1f))
            draw { c1 }
        }
        4 -> { // тень
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = strokeSolid
            p.setShadowLayer(
                s.shadow * textPx * 0.06f + 1f,
                s.shadow * textPx * 0.02f,
                s.shadow * textPx * 0.035f,
                0xAA000000.toInt()
            )
            draw { c1 }
        }
        5 -> { // стекло
            p.style = Paint.Style.FILL
            draw { withAlpha(s.color1, s.alpha * 0.30f) }
            p.style = Paint.Style.STROKE
            p.strokeWidth = max(textPx * 0.012f, 1.5f)
            draw { withAlpha(0xFFFFFFFF.toInt(), s.alpha * 0.9f) }
        }
        6 -> { // два цвета
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = strokeSolid
            draw { if (it < split) c1 else c2 }
        }
        else -> {
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = strokeSolid
            draw { c1 }
        }
    }
    p.shader = null
    p.clearShadowLayer()
}

private fun applyFx(p: Paint, s: ClockStyle, scale: Float) {
    when (s.fill) {
        3 -> p.setShadowLayer(scale * (0.01f + s.glow * 0.05f), 0f, 0f, withAlpha(s.color2, 1f))
        4 -> p.setShadowLayer(
            scale * (0.005f + s.shadow * 0.02f), scale * 0.006f, scale * 0.012f, 0xAA000000.toInt()
        )
        else -> p.clearShadowLayer()
    }
}

/* ---------------- Аналоговые ---------------- */

@Composable
private fun AnalogFace(style: ClockStyle, parts: TimeParts, sizeFactor: Float, maxWidthPx: Float) {
    val density = LocalDensity.current
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    val d = with(density) { 250.dp.toPx() } * style.size * sizeFactor
    val sx = min(style.width, maxWidthPx / d)
    val sy = style.height
    val typeface = remember(style.fontIndex, style.weight) {
        ClockFonts.typeface(style.fontIndex, style.weight)
    }
    val c1 = withAlpha(style.color1, style.alpha)
    val c2 = withAlpha(style.color2, style.alpha)

    Canvas(
        Modifier.size(
            with(density) { (d * sx).toDp() },
            with(density) { (d * sy).toDp() }
        )
    ) {
        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            nc.save()
            nc.translate(size.width / 2f, size.height / 2f)
            nc.scale(sx, sy)

            val r = d / 2f * 0.94f
            val thin = d * 0.006f * (0.6f + style.weight * 1.4f)
            val thick = thin * 2.6f

            paint.reset()
            paint.isAntiAlias = true
            paint.strokeCap = Paint.Cap.ROUND
            applyFx(paint, style, d)

            // кольцо
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = thin
            paint.color = withAlpha(style.color1, style.alpha * 0.35f)
            nc.drawCircle(0f, 0f, r, paint)

            // деления
            for (i in 0 until 60) {
                val major = i % 5 == 0
                val len = if (major) r * 0.10f else r * 0.045f
                val a = Math.toRadians(i * 6.0)
                val sA = sin(a).toFloat()
                val cA = cos(a).toFloat()
                paint.strokeWidth = if (major) thick * 0.6f else thin
                paint.color = if (major) c1 else withAlpha(style.color1, style.alpha * 0.55f)
                nc.drawLine(sA * (r - len), -cA * (r - len), sA * r * 0.98f, -cA * r * 0.98f, paint)
            }

            // цифры 12 / 3 / 6 / 9
            paint.style = Paint.Style.FILL
            paint.typeface = typeface
            paint.textSize = r * 0.2f
            paint.textAlign = Paint.Align.CENTER
            paint.color = c1
            val fm = paint.fontMetrics
            listOf(12 to 0.0, 3 to 90.0, 6 to 180.0, 9 to 270.0).forEach { (n, deg) ->
                val a = Math.toRadians(deg)
                val x = sin(a).toFloat() * r * 0.70f
                val y = -cos(a).toFloat() * r * 0.70f - (fm.ascent + fm.descent) / 2f
                nc.drawText(n.toString(), x, y, paint)
            }

            fun hand(deg: Float, len: Float, w: Float, color: Int) {
                val a = Math.toRadians(deg.toDouble())
                val sA = sin(a).toFloat()
                val cA = cos(a).toFloat()
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = w
                paint.color = color
                nc.drawLine(-sA * len * 0.12f, cA * len * 0.12f, sA * len, -cA * len, paint)
            }

            hand(((parts.h % 12) + parts.m / 60f) * 30f, r * 0.50f, thick * 1.6f, c1)
            hand((parts.m + parts.s / 60f) * 6f, r * 0.76f, thick * 1.1f, c1)
            if (style.showSeconds) hand(parts.s * 6f, r * 0.86f, thin * 1.4f, c2)

            paint.style = Paint.Style.FILL
            paint.color = c2
            nc.drawCircle(0f, 0f, thick * 1.1f, paint)
            nc.restore()
        }
    }
}

/* ---------------- Бинарные ---------------- */

@Composable
private fun BinaryFace(style: ClockStyle, parts: TimeParts, sizeFactor: Float, maxWidthPx: Float) {
    val density = LocalDensity.current
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    val cell = with(density) { 54.dp.toPx() } * style.size * sizeFactor

    val digits = buildList {
        add(parts.h / 10); add(parts.h % 10)
        add(parts.m / 10); add(parts.m % 10)
        if (style.showSeconds) {
            add(parts.s / 10); add(parts.s % 10)
        }
    }
    val bitsPerDigit = listOf(2, 4, 3, 4, 3, 4)
    val groupGap = cell * 0.6f
    val xs = ArrayList<Float>()
    var x = 0f
    digits.indices.forEach { i ->
        if (i > 0) x += cell + (if (i % 2 == 0) groupGap else 0f)
        xs.add(x)
    }
    val baseW = x + cell
    val baseH = cell * 4f
    val sx = min(style.width, maxWidthPx / baseW)
    val sy = style.height
    val c1 = withAlpha(style.color1, style.alpha)
    val c2 = withAlpha(style.color2, style.alpha)
    val off = withAlpha(style.color1, style.alpha * 0.16f)

    Canvas(
        Modifier.size(
            with(density) { (baseW * sx).toDp() },
            with(density) { (baseH * sy).toDp() }
        )
    ) {
        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            nc.save()
            nc.translate(size.width / 2f, size.height / 2f)
            nc.scale(sx, sy)
            nc.translate(-baseW / 2f, -baseH / 2f)

            paint.reset()
            paint.isAntiAlias = true
            paint.style = Paint.Style.FILL
            applyFx(paint, style, cell * 4f)

            val radius = cell * (0.30f + 0.12f * style.weight)
            digits.forEachIndexed { i, digit ->
                val nb = bitsPerDigit[i]
                for (row in 0 until 4) {
                    val bit = 3 - row
                    if (bit >= nb) continue
                    val on = ((digit shr bit) and 1) == 1
                    paint.color = if (on) (if (i >= 2 && style.fill == 6) c2 else c1) else off
                    nc.drawCircle(xs[i] + cell / 2f, row * cell + cell / 2f, radius, paint)
                }
            }
            nc.restore()
        }
    }
}
