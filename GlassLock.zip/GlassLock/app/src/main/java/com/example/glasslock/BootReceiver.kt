package com.example.glasslock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Поднимает сервис блокировки после перезагрузки телефона. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (ClockStyleStore(context).lockEnabled && Permissions.canOverlay(context)) {
            try {
                LockScreenService.start(context, showNow = true)
            } catch (_: Exception) {
            }
        }
    }
}
