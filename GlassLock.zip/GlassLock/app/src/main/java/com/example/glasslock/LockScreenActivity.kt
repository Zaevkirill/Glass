package com.example.glasslock

import android.app.KeyguardManager
import android.content.Intent
import android.os.Build
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LockScreenActivity : ComponentActivity() {

    private lateinit var ticker: TimeTicker
    private lateinit var store: ClockStyleStore
    private var styleState by mutableStateOf(ClockStyle())
    private var resetKey by mutableIntStateOf(0)

    private val handler = Handler(Looper.getMainLooper())
    private var faceTries = 0
    private var faceStartedAt = 0L

    // авто-открытие шторки после разблокировки системой (лицо)
    private var autoOpenKey by mutableIntStateOf(0)
    private var autoOpenMode = 0           // 1 — телефон уже разблокирован, 2 — нужен запрос разблокировки
    private var unlocking = false
    private var needsReset = false
    private var userPresentRegistered = false
    private val userPresentReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            onSystemUnlocked()
        }
    }
    private val autoUnlockRunnable = Runnable { runAutoUnlock() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        isReady = true
        setupWindow()

        store = ClockStyleStore(this)
        ticker = TimeTicker(this)
        ticker.onScreenOn = { scheduleAutoUnlock() }
        styleState = store.load()

        // Кнопка «Назад» на экране блокировки ничего не делает
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })

        setContent {
            LockScreenContent(
                style = styleState,
                ticker = ticker,
                resetKey = resetKey,
                autoOpenKey = autoOpenKey,
                onAutoOpened = { onAutoOpened() },
                onUnlock = { onCancelled -> unlock(onCancelled) }
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)

        // Без PIN/пароля системный keyguard снимается полностью — виден только наш экран.
        // С PIN наш экран лежит поверх keyguard, а после свайпа система спросит PIN.
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onStart() {
        super.onStart()
        isForeground = true
        if (!userPresentRegistered) {
            ContextCompat.registerReceiver(
                this, userPresentReceiver, IntentFilter(Intent.ACTION_USER_PRESENT),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            userPresentRegistered = true
        }
        ticker.register()          // TIME_TICK / TIME_CHANGED / TIMEZONE_CHANGED / SCREEN_ON
    }

    override fun onResume() {
        super.onResume()
        ticker.refresh()           // принудительное обновление при каждом пробуждении
        styleState = store.load()
        if (needsReset) {
            needsReset = false
            resetKey++
        }
        scheduleAutoUnlock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        ticker.refresh()
        faceTries = 0
        unlocking = false
        autoOpenKey = 0
        isReady = true
        if (needsReset) {
            needsReset = false
            resetKey++
        }
    }

    override fun onStop() {
        handler.removeCallbacks(autoUnlockRunnable)
        faceTries = 0          // новая попытка при следующем включении экрана
        isForeground = false
        if (userPresentRegistered) {
            try {
                unregisterReceiver(userPresentReceiver)
            } catch (_: IllegalArgumentException) {
            }
            userPresentRegistered = false
        }
        unlocking = false
        autoOpenKey = 0
        ticker.unregister()
        super.onStop()
    }

    override fun onDestroy() {
        isForeground = false
        isReady = false
        instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    /**
     * Разблокировка по лицу: вызываем системный запрос разблокировки. Он показывает
     * системный экран проверки, где лицо распознаёт сам телефон, и при успехе
     * сразу открывает рабочий стол. Если лицо не подошло — остаёмся на нашем экране,
     * свайп вверх повторит попытку.
     */
    private fun scheduleAutoUnlock() {
        val s = styleState
        if (!s.faceUnlock || faceTries >= 2) return
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) return // без защиты экран открывался бы сам
        handler.removeCallbacks(autoUnlockRunnable)
        handler.postDelayed(autoUnlockRunnable, (s.faceDelay * 1000f).toLong())
    }

    private fun runAutoUnlock() {
        val pm = getSystemService(PowerManager::class.java)
        // только если экран реально включён — иначе телефон бы просыпался сам
        if (faceTries >= 2 || isFinishing || !pm.isInteractive) return
        faceTries++
        faceStartedAt = SystemClock.elapsedRealtime()
        unlock {
            // система отменила запрос сразу же (экран ещё не готов) — повторяем один раз
            if (SystemClock.elapsedRealtime() - faceStartedAt < 1200L) scheduleAutoUnlock()
        }
    }

    private fun unlock(onCancelled: () -> Unit) {
        unlocking = true
        needsReset = true
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    hideLock()
                }

                override fun onDismissCancelled() {
                    unlocking = false
                    onCancelled()
                }

                override fun onDismissError() {
                    hideLock()
                }
            })
        } else {
            hideLock()
        }
    }

    /**
     * Окно не уничтожается, а уходит на задний план: следующее включение экрана
     * просто поднимает уже готовую активность (без пересоздания и перекомпоновки).
     */
    /** Телефон разблокирован системой (лицо) — открываем шторку сами. */
    private fun onSystemUnlocked() {
        val km = getSystemService(KeyguardManager::class.java)
        if (!styleState.autoOpen || !km.isDeviceSecure) return
        triggerAutoOpen(1)
    }

    private fun triggerAutoOpen(mode: Int) {
        if (!isForeground || unlocking || autoOpenKey > 0) return
        autoOpenMode = mode
        needsReset = true
        autoOpenKey = 1
    }

    /** Вызывается, когда шторка уже уехала вверх. */
    private fun onAutoOpened() {
        hideLock()
    }

    private fun hideLock() {
        isReady = false
        if (!moveTaskToBack(true)) finish()
    }

    companion object {
        @Volatile
        var isForeground = false

        /** Окно создано и лежит наверху (даже если экран выключен) — повторный запуск не нужен. */
        @Volatile
        var isReady = false

        @Volatile
        var instance: LockScreenActivity? = null
    }
}

@Composable
private fun LockScreenContent(
    style: ClockStyle,
    ticker: TimeTicker,
    resetKey: Int,
    autoOpenKey: Int,
    onAutoOpened: () -> Unit,
    onUnlock: (onCancelled: () -> Unit) -> Unit
) {
    val now = ticker.now
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    var heightPx by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(resetKey) { offset.snapTo(0f) }

    // авто-открытие: после разблокировки системой шторка уезжает вверх сама
    LaunchedEffect(autoOpenKey) {
        if (autoOpenKey > 0) {
            delay(120)
            offset.animateTo(-heightPx, tween(320))
            onAutoOpened()
        }
    }

    // анимация подсказки читается только в слое отрисовки — без перекомпоновки экрана
    val pulse = rememberInfiniteTransition(label = "pulse")
    val hintAlpha = pulse.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse),
        label = "hint"
    )

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { heightPx = it.height.toFloat() }
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { delta ->
                    scope.launch {
                        offset.snapTo((offset.value + delta).coerceIn(-heightPx, 0f))
                    }
                },
                onDragStopped = { velocity ->
                    scope.launch {
                        if (offset.value < -heightPx * 0.22f || velocity < -1400f) {
                            offset.animateTo(-heightPx, tween(220))
                            onUnlock {
                                scope.launch {
                                    offset.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                                }
                            }
                        } else {
                            offset.animateTo(0f, spring(Spring.DampingRatioLowBouncy))
                        }
                    }
                }
            )
    ) {
        // затемнение для читаемости (обои остаются родными)
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = 1f - (-offset.value / heightPx).coerceIn(0f, 1f) }
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = style.dim),
                            Color.Transparent,
                            Color.Black.copy(alpha = (style.dim + 0.1f).coerceAtMost(0.8f))
                        )
                    )
                )
        )

        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val p = (-offset.value / heightPx).coerceIn(0f, 1f)
                    translationY = offset.value
                    alpha = 1f - p * 0.9f
                    val sc = 1f - p * 0.08f
                    scaleX = sc
                    scaleY = sc
                }
        ) {
            IosClock(
                style = style,
                now = now,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(top = (48f + style.topOffset).dp)
            )

            if (style.showBattery) {
                BatteryIndicator(
                    style = style,
                    now = now,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 10.dp, end = 18.dp)
                )
            }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Проведите вверх, чтобы разблокировать",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.graphicsLayer {
                        alpha = if (style.showHint) hintAlpha.value else 0f
                    }
                )
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier
                        .graphicsLayer { alpha = if (style.showHint) 1f else 0f }
                        .width(140.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.9f))
                )
            }
        }
    }
}
