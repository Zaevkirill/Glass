package com.example.glasslock

import android.app.KeyguardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.launch

class LockScreenActivity : ComponentActivity() {

    private lateinit var ticker: TimeTicker
    private lateinit var store: ClockStyleStore
    private var styleState by mutableStateOf(ClockStyle())
    private var resetKey by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isShowing = true
        setupWindow()

        store = ClockStyleStore(this)
        ticker = TimeTicker(this)
        styleState = store.load()

        // Кнопка «Назад» на экране блокировки ничего не делает
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })

        setContent {
            LockScreenContent(
                style = styleState,
                ticker = ticker,
                resetKey = resetKey,
                onUnlock = { onCancelled -> unlock(onCancelled) }
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)

        // Без PIN/пароля системный keyguard снимается полностью — виден только наш экран.
        // С PIN наш экран лежит поверх keyguard, а после свайпа система спросит PIN.
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onStart() {
        super.onStart()
        ticker.register()          // TIME_TICK / TIME_CHANGED / TIMEZONE_CHANGED / SCREEN_ON
    }

    override fun onResume() {
        super.onResume()
        ticker.refresh()           // принудительное обновление при каждом пробуждении
        styleState = store.load()
        resetKey++
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        ticker.refresh()
        resetKey++
    }

    override fun onStop() {
        ticker.unregister()
        super.onStop()
    }

    override fun onDestroy() {
        isShowing = false
        super.onDestroy()
    }

    private fun unlock(onCancelled: () -> Unit) {
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    finishAndRemoveTask()
                }

                override fun onDismissCancelled() {
                    onCancelled()
                }

                override fun onDismissError() {
                    finishAndRemoveTask()
                }
            })
        } else {
            finishAndRemoveTask()
        }
    }

    companion object {
        @Volatile
        var isShowing = false
    }
}

@Composable
private fun LockScreenContent(
    style: ClockStyle,
    ticker: TimeTicker,
    resetKey: Int,
    onUnlock: (onCancelled: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val now = ticker.now
    val hours = remember(now) { TimeFormat.hours(context, now) }
    val minutes = remember(now) { TimeFormat.minutes(now) }
    val date = remember(now) { TimeFormat.date(now) }

    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    var heightPx by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(resetKey) { offset.snapTo(0f) }

    val progress = (-offset.value / heightPx).coerceIn(0f, 1f)

    val pulse = rememberInfiniteTransition(label = "pulse")
    val hintAlpha by pulse.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse),
        label = "hint"
    )

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { heightPx = it.height.toFloat() }
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { delta ->
                    scope.launch {
                        offset.snapTo((offset.value + delta).coerceIn(-heightPx, 0f))
                    }
                },
                onDragStopped = { velocity ->
                    scope.launch {
                        if (offset.value < -heightPx * 0.22f || velocity < -1400f) {
                            offset.animateTo(-heightPx, tween(220))
                            onUnlock {
                                scope.launch {
                                    offset.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                                }
                            }
                        } else {
                            offset.animateTo(0f, spring(Spring.DampingRatioLowBouncy))
                        }
                    }
                }
            )
    ) {
        // Лёгкое затемнение сверху/снизу для читаемости (обои остаются родными)
        Box(
            Modifier
                .fillMaxSize()
                .alpha(1f - progress)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = 0.22f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.32f)
                        )
                    )
                )
        )

        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = offset.value
                    alpha = 1f - progress * 0.9f
                    val s = 1f - progress * 0.08f
                    scaleX = s
                    scaleY = s
                }
        ) {
            IosClock(
                style = style,
                hours = hours,
                minutes = minutes,
                date = date,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(top = 48.dp)
            )

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Проведите вверх, чтобы разблокировать",
                    color = Color.White.copy(alpha = 0.85f * hintAlpha),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier
                        .width(140.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.9f))
                )
            }
        }
    }
}
