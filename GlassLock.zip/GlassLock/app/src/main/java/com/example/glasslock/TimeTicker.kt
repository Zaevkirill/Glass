package com.example.glasslock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.text.format.DateFormat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Держит актуальное время. Подписан на системные события:
 * TIME_TICK, TIME_CHANGED, TIMEZONE_CHANGED, DATE_CHANGED и SCREEN_ON.
 * Дополнительно refresh() вызывается из onResume().
 */
class TimeTicker(private val context: Context) {

    var now by mutableLongStateOf(System.currentTimeMillis())
        private set

    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
                TimeZone.setDefault(null) // сбросить кэш часового пояса JVM
            }
            refresh()
        }
    }

    fun refresh() {
        now = System.currentTimeMillis()
    }

    fun register() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(
            context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
        )
        registered = true
        refresh()
    }

    fun unregister() {
        if (!registered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
        }
        registered = false
    }
}

object TimeFormat {
    fun hours(context: Context, millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return if (DateFormat.is24HourFormat(context)) {
            "%02d".format(cal.get(Calendar.HOUR_OF_DAY))
        } else {
            val h = cal.get(Calendar.HOUR)
            (if (h == 0) 12 else h).toString()
        }
    }

    fun minutes(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return "%02d".format(cal.get(Calendar.MINUTE))
    }

    fun date(millis: Long): String =
        SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())
            .format(Date(millis))
            .replaceFirstChar { it.uppercase() }
}
