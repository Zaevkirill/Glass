package com.example.glasslock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.text.format.DateFormat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Держит актуальное время. Подписан на системные события:
 * TIME_TICK, TIME_CHANGED, TIMEZONE_CHANGED, DATE_CHANGED и SCREEN_ON.
 * Дополнительно refresh() вызывается из onResume().
 */
class TimeTicker(private val context: Context) {

    var now by mutableLongStateOf(System.currentTimeMillis())
        private set

    private var registered = false

    /** Вызывается при ACTION_SCREEN_ON. */
    var onScreenOn: (() -> Unit)? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
                TimeZone.setDefault(null) // сбросить кэш часового пояса JVM
            }
            refresh()
            if (intent.action == Intent.ACTION_SCREEN_ON) onScreenOn?.invoke()
        }
    }

    fun refresh() {
        now = System.currentTimeMillis()
    }

    fun register() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(
            context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
        )
        registered = true
        refresh()
    }

    fun unregister() {
        if (!registered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
        }
        registered = false
    }
}

data class TimeParts(val h: Int, val m: Int, val s: Int)

object TimeFormat {
    fun parts(context: Context, millis: Long, hourMode: Int): TimeParts {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        val use24 = when (hourMode) {
            1 -> true
            2 -> false
            else -> DateFormat.is24HourFormat(context)
        }
        val h = if (use24) cal.get(Calendar.HOUR_OF_DAY)
        else cal.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        return TimeParts(h, cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND))
    }

    fun date(millis: Long, format: Int): String {
        val pattern = when (format) {
            1 -> "EEE, d MMM"
            2 -> "dd.MM.yyyy"
            3 -> "d MMMM"
            4 -> "EEEE"
            else -> "EEEE, d MMMM"
        }
        return SimpleDateFormat(pattern, Locale.getDefault())
            .format(Date(millis))
            .replaceFirstChar { it.uppercase() }
    }
}
